
import React from 'react'
import ReactDOM from 'react-dom/client'

const App = () => (
  <div>
    <h1>BLE Tracker Frontend</h1>
    <p>Login and dashboard coming soon.</p>
  </div>
)

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
